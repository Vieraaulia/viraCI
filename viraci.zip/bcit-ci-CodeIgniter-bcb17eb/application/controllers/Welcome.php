<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function tambahdata()
	{
		$this->load->view('tambahdata');
	}
	public function tampildata()
	{
		$data['query']= $this->db->get('mahasiswa')->result_array();
		$this->load->view('tampildata', $data);
	}
	public function updatee($id)
	{
		$this->db->where('id',$id);
		$data['query']= $this->db->get('mahasiswa')->row_array();
		$this->load->view('updatedata', $data);
	}
	function insert(){
		$data = array(
			'id'=>$this->input->post('id'),
			'nama'=>$this->input->post('nama'),
			'jurusan'=>$this->input->post('jurusan'),
		);
		$this->db->insert('mahasiswa', $data);
		redirect('welcome/tampildata');
	}
	function update($id){
		$data = array(
			'id'=>$this->input->post('id'),
			'nama'=>$this->input->post('nama'),
			'jurusan'=>$this->input->post('jurusan')
		);
		$this->db->where('id',$id);
		$this->db->update('mahasiswa', $data);
		redirect('welcome/tampildata');
	}
	function delete($id){
		$this->db->where('id', $id);
		$this->db->delete('mahasiswa');
		redirect('welcome/tampildata');
	}
}
