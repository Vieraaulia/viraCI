<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="card my-4 mt-3 mt-5">
    <div class="d-grip gap-2 col-12 mt-2">
    <table class="table">
  <thead class="table-dark">
    <tr style="text-align:center;">
      <th scope="col">ID</th>
      <th scope="col">NAMA</th>
      <th scope="col">JURUSAN</th>
      <th scope="col">AKSI</th>
    </tr>
  </thead>
    <?php foreach ($query as $query) { ?>
  <tbody>
    <tr class="text-center">
      <td><?=$query['id']?></td>
      <td><?=$query['nama']?></td>
      <td><?=$query['jurusan']?></td>
      <td>
        <a href="<?=site_url('welcome/updatee/'.$query['id'])?>" class="btn btn-primary">Update</a>&nbsp;
        <a href="<?=site_url('welcome/delete/'.$query['id'])?>" class="btn btn-danger">Delete</a>
      </td>
    </td>
    </tr>
    </tbody> 
        <?php }?>
    </table>
    </div>
    </div>
</body>
</html>